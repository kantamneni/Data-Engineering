Project: Data Modeling with Postgres

A startup company Sparkify , that Provides music streaming wants to analyze users listening data .
Company Analytics team is particulaly interested in what songs Customers are listening .
The song deatils and the custmoers activity data from the applicationa are currently avilable and stored in the format of JSON.
The comapany would like to work with data engineer to create a Postgres database with tables designed to optimized queries on song play analysis .
The below data modeling wokr was desinged for this project.
The data we receive is in Json files , which will take time to analyze , our goal is to import the data into Postgres db and use Modeling 
techniques to allow fast retrieval of data , here I prefer STAR schema modeling to work on this project.

The STAR schema modeling consists of one or more FACT tables referencing any number of DIMENSION tables , these tables help 
Sparkify to solve simplified business logic .
-> What song should play next for the sparkify user, based on past activity
-> which song an user would be interested in listening  at particular point of time.

Below is the STAR schema model for this project
FACT table - songplays -> attributes referencing to the dimensions tables
DIMENSION tables - usres,songs,artists, time.

Above tables will help analytics team of Sparkify to run different kinds of analysis to recommend a  sparkify business team of users.
Favorite songs of user based on the week day: BY joining songplay and songs and user table based on level.
Recenet listened to songs : By Joining songplays and user table can show recommendation on the app based on subscription level.
Help in recommending most popular songs of the day/week.

#ETL Pipeline
Create FACT table from the domension tables and log_data called songplays
Create DIMENSION tables songs and artist from extracting songs_data by selected columns.
Create DIMENSION tables users and time from extracting log_data by selected columns.

work-flow.

1.test.ipynb displays the first few rows of each table to let you check your database.
2.create_tables.py drops and creates your tables ,we run this file to reset the tables before each time we run ETL scripts
3.etl.ipynb reads and process single file from song_data and log_data and loads data into tables , here we have detailed instructions on ETL process  for each table
4.etl.py reads and process files form song_data and log_data and load them into tables 
5.sql_queries.py file have all the sql queries and is imported in to the three files above

Execute the below files in order to each time before pipeline
1.create_tables.py
2.Sql_Queries.py
2.etl.ipynb/etl.py
3.test.ipynb



